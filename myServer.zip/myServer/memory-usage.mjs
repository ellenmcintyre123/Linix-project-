#!/usr/bin/env zx

const os = require('os');

// Function to get server memory usage
function getServerMemoryUsage() {
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const usedMemory = totalMemory - freeMemory;

  return {
    totalMemory: totalMemory / (1024 * 1024), // Convert to MB
    usedMemory: usedMemory / (1024 * 1024), // Convert to MB
    freeMemory: freeMemory / (1024 * 1024), // Convert to MB
  };
}

// Main function
function main() {
  const serverMemoryUsage = getServerMemoryUsage();
  console.log(`Server Memory Usage: Total=${serverMemoryUsage.totalMemory.toFixed(2)} MB, Used=${serverMemoryUsage.usedMemory.toFixed(2)} MB, Free=${serverMemoryUsage.freeMemory.toFixed(2)} MB`);
}

// Run the main function
main();

