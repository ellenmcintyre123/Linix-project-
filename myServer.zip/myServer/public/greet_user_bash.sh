#!/bin/bash

echo "Content-type: text/html"
echo ""
echo "<html><body>"

echo "Enter your name:"
read name

echo "Hello, $name! Welcome to the bash script."

echo "</body></html>"
